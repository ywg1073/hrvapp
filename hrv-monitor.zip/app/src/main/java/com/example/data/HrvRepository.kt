package com.example.data

import kotlinx.coroutines.flow.Flow

class HrvRepository(private val hrvDao: HrvDao) {
    val allRecords: Flow<List<HrvRecord>> = hrvDao.getAllRecords()

    suspend fun insertRecord(record: HrvRecord): Long {
        return hrvDao.insertRecord(record)
    }

    suspend fun deleteRecord(record: HrvRecord) {
        hrvDao.deleteRecord(record)
    }

    suspend fun deleteRecordById(id: Int) {
        hrvDao.deleteRecordById(id)
    }
}

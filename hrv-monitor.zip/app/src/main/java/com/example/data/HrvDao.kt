package com.example.data

import androidx.room.Dao
import androidx.room.Delete
import androidx.room.Insert
import androidx.room.OnConflictStrategy
import androidx.room.Query
import kotlinx.coroutines.flow.Flow

@Dao
interface HrvDao {
    @Query("SELECT * FROM hrv_records ORDER BY startTime DESC")
    fun getAllRecords(): Flow<List<HrvRecord>>

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insertRecord(record: HrvRecord): Long

    @Delete
    suspend fun deleteRecord(record: HrvRecord)

    @Query("DELETE FROM hrv_records WHERE id = :id")
    suspend fun deleteRecordById(id: Int)
}

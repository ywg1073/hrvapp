package com.example.data

import androidx.room.Entity
import androidx.room.PrimaryKey

@Entity(tableName = "hrv_records")
data class HrvRecord(
    @PrimaryKey(autoGenerate = true) val id: Int = 0,
    val startTime: Long,
    val endTime: Long,
    val avgHr: Double,
    val sdnn: Double,
    val rmssd: Double,
    val pnn50: Double,
    val lf: Double,
    val hf: Double,
    val lfHf: Double,
    val prematureCount: Int,
    val diagnostic: String,
    val logContent: String
)

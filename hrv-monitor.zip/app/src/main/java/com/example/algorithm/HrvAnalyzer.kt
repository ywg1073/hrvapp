package com.example.algorithm

import java.util.Calendar
import kotlin.math.abs
import kotlin.math.cos
import kotlin.math.PI
import kotlin.math.sin
import kotlin.math.sqrt

// --- 昼夜动态自适应生理阈值切换配置 ---
data class ThresholdConfig(
    val mode: String,
    val prematureRatio: Double,
    val compensateRatio: Double,
    val sdnnLimit: Double,
    val pnn100Limit: Double,
    val rmssdLimit: Double,
    val ratioLimit: Double
)

// --- 时域 HRV 计算结果 ---
data class HrvTimeDomain(
    val avgHr: Double,
    val sdnn: Double,
    val rmssd: Double,
    val pnn50: Double
)

// --- 频域 HRV 计算结果 ---
data class HrvFrequencyDomain(
    val lf: Double,
    val hf: Double,
    val lfHfRatio: Double
)

// --- 最终滑窗计算综合输出 ---
data class HrvAnalysisResult(
    val windowLabel: String,
    val mode: String,
    val avgHr: Double,
    val sdnn: Double,
    val rmssd: Double,
    val pnn50: Double,
    val lf: Double,
    val hf: Double,
    val lfHfRatio: Double,
    val recentPrematureIncrement: Int,
    val totalPrematureCount: Int,
    val diagnosticStatus: String,
    val timestamp: Long = System.currentTimeMillis()
)

class HrvAnalyzer {

    companion object {
        const val MIN_WINDOW_SIZE = 30            // 快速启动的最小计算样本数
        const val REQUIRED_WINDOW_SIZE = 61       // 完整全维滑动窗口容量
    }

    // --- 全局状态队列缓冲区 ---
    val rrBuffer = mutableListOf<Double>()                  // 纯净窦性心律滑动队列（先进先出）
    val filterHistory = mutableListOf<Double>()              // 自适应动态历史滤波基准
    var consecutiveWarningCount = 0   // 房颤高度紊乱连续滑窗异常计数器

    // --- 状态机及早搏专属全局变量 ---
    var prematureBeatCount = 0        // 历史累计早搏总次数
    var lastValidSinusRr: Double? = null      // 用于硬件报文重复值过滤的上一跳有效窦性 RR
    var lastRawRr: Double? = null              // 用于突变梯度相邻差分校验的上一跳物理 RR
    
    // 有限状态机常驻状态：0-窦性稳定, 1-单发待代偿, 2-连发锁定, 3-恢复期阶梯1, 4-恢复期阶梯2
    var prematureState = 0             
    var sinusConfirmCounter = 0       // 恢复期内连续正常窦性心搏计数器
    var recoveryAbnormalCounter = 0   // 恢复期内轻微毛刺连续异常容错计数器

    val windowPrematureTracker = mutableListOf<Int>() // 窗口内早搏增加记录器

    fun reset() {
        rrBuffer.clear()
        filterHistory.clear()
        consecutiveWarningCount = 0
        prematureBeatCount = 0
        lastValidSinusRr = null
        lastRawRr = null
        prematureState = 0
        sinusConfirmCounter = 0
        recoveryAbnormalCounter = 0
        windowPrematureTracker.clear()
    }

    // --- 昼夜动态自适应生理阈值切换引擎 ---
    fun getAdaptiveThresholds(): ThresholdConfig {
        val hour = Calendar.getInstance().get(Calendar.HOUR_OF_DAY)
        return if (hour >= 23 || hour < 7) {
            ThresholdConfig(
                mode = "🌙 夜间睡眠生理模式",
                prematureRatio = 0.85,
                compensateRatio = 1.12,
                sdnnLimit = 100.0,
                pnn100Limit = 0.35,
                rmssdLimit = 80.0,
                ratioLimit = 1.30
            )
        } else {
            ThresholdConfig(
                mode = "☀️ 日间清醒活动模式",
                prematureRatio = 0.80,
                compensateRatio = 1.16,
                sdnnLimit = 120.0,
                pnn100Limit = 0.40,
                rmssdLimit = 100.0,
                ratioLimit = 1.35
            )
        }
    }

    // --- 独立且唯一的时域极值裁剪引擎 ---
    fun getTrimmedSinusRr(rawWindowRr: List<Double>): List<Double> {
        val indexedRr = rawWindowRr.mapIndexed { index, value -> index to value }.toMutableList()
        indexedRr.sortBy { it.second }
        val trimCount = (rawWindowRr.size * 0.05).toInt().coerceAtLeast(1)
        
        // 剔除前后各 5% 极端离群值
        val trimmedIndexed = indexedRr.subList(trimCount, indexedRr.size - trimCount).toMutableList()
        trimmedIndexed.sortBy { it.first } // 关键：按发生时序回正，捍卫相邻相关性指标
        
        return trimmedIndexed.map { it.second }
    }

    // --- 数学计算层：高精度时域 HRV 模块 ---
    fun calculateHrvTimeDomain(trimmedRr: List<Double>): HrvTimeDomain {
        val n = trimmedRr.size
        if (n < 2) {
            return HrvTimeDomain(0.0, 0.0, 0.0, 0.0)
        }
        val totalRr = trimmedRr.sum()
        val meanRr = totalRr / n
        val avgHr = 60000.0 / meanRr
        
        val deviationSquares = trimmedRr.map { (it - meanRr) * (it - meanRr) }
        val variance = deviationSquares.sum() / (n - 1) // 贝塞尔校正
        val sdnn = sqrt(variance)
        
        val diffs = (1 until n).map { abs(trimmedRr[it] - trimmedRr[it - 1]) }
        val diffCount = diffs.size
        val sqDiffs = diffs.map { it * it }
        val rmssd = sqrt(sqDiffs.sum() / diffCount)
        
        val nn50Count = diffs.count { it > 50.0 }
        val pnn50 = (nn50Count.toDouble() / diffCount) * 100.0
        
        return HrvTimeDomain(avgHr, sdnn, rmssd, pnn50)
    }

    // --- 数学计算层：等间隔重采样功率谱 DFT 频域分析核心引擎 ---
    fun calculateHrvFrequencyDomain(trimmedRr: List<Double>, fs: Double = 4.0): HrvFrequencyDomain {
        val rrSecs = trimmedRr.map { it / 1000.0 }
        val tBeats = mutableListOf(0.0)
        for (r in rrSecs) {
            tBeats.add(tBeats.last() + r)
        }
        
        val totalDuration = tBeats.last()
        val dt = 1.0 / fs
        
        val tResampled = mutableListOf<Double>()
        var currT = 0.0
        while (currT <= totalDuration) {
            tResampled.add(currT)
            currT += dt
        }
        
        val nSamples = tResampled.size
        if (nSamples < 8) {
            return HrvFrequencyDomain(0.0, 0.0, 0.0)
        }
        
        val rrResampled = mutableListOf<Double>()
        for (t in tResampled) {
            var idx = 0
            while (idx < tBeats.size - 1 && tBeats[idx + 1] < t) {
                idx++
            }
            if (idx >= tBeats.size - 1) {
                rrResampled.add(rrSecs.last())
            } else {
                val t0 = tBeats[idx]
                val t1 = tBeats[idx + 1]
                val y0 = rrSecs[idx]
                val y1 = rrSecs[idx + 1]
                val value = if (t1 != t0) {
                    y0 + (y1 - y0) * (t - t0) / (t1 - t0)
                } else {
                    y0
                }
                rrResampled.add(value)
            }
        }
        
        val meanVal = rrResampled.sum() / nSamples
        val signalDetrended = rrResampled.map { it - meanVal }
        
        val windowedSignal = mutableListOf<Double>()
        var winEnergySum = 0.0
        for (n in 0 until nSamples) {
            val w = 0.5 * (1.0 - cos(2.0 * PI * n / (nSamples - 1)))
            windowedSignal.add(signalDetrended[n] * w)
            winEnergySum += w * w
        }
        
        val df = fs / nSamples
        val normFactor = if (winEnergySum > 0.0) 2.0 / (fs * winEnergySum) else 1.0
        
        var lfPower = 0.0
        var hfPower = 0.0
        
        for (k in 1 until nSamples / 2) {
            val freq = k * df
            if (freq in 0.04..0.40) {
                var realPart = 0.0
                var imagPart = 0.0
                for (n in 0 until nSamples) {
                    val angle = 2.0 * PI * k * n / nSamples
                    realPart += windowedSignal[n] * cos(angle)
                    imagPart -= windowedSignal[n] * sin(angle)
                }
                
                val psd = (realPart * realPart + imagPart * imagPart) * normFactor
                if (freq >= 0.04 && freq < 0.15) {
                    lfPower += psd * df
                } else if (freq >= 0.15 && freq <= 0.40) {
                    hfPower += psd * df
                }
            }
        }
        
        val lfMs2 = lfPower * 1000000.0
        val hfMs2 = hfPower * 1000000.0
        val lfHfRatio = if (hfMs2 > 0.0) lfMs2 / hfMs2 else 0.0
        
        return HrvFrequencyDomain(lfMs2, hfMs2, lfHfRatio)
    }

    private fun List<Double>.median(): Double {
        if (isEmpty()) return 0.0
        val sorted = sorted()
        return if (sorted.size % 2 == 1) {
            sorted[sorted.size / 2]
        } else {
            (sorted[sorted.size / 2 - 1] + sorted[sorted.size / 2]) / 2.0
        }
    }

    // --- 心律失常分级校验与多状态拦截模块 ---
    fun checkArrhythmiaSafety(
        trimmedRr: List<Double>,
        avgHr: Double,
        sdnn: Double,
        rmssd: Double,
        pnn50: Double,
        prematureIncrement: Int
    ): String {
        val cfg = getAdaptiveThresholds()
        
        // 独立且不干扰正常运算的心搏过速/过缓筛查前缀
        var hrAlertPrefix = ""
        if (avgHr < 55.0) {
            hrAlertPrefix = "【⚠️ 提示：静息心动过缓】"
        } else if (avgHr > 100.0 && avgHr <= 130.0) {
            hrAlertPrefix = "【⚠️ 提示：静息心率偏高】"
        }
        
        if (avgHr > 130.0) {
            consecutiveWarningCount = 0
            return "🏃 运动正常状态 (高心率房颤筛查屏蔽)"
        }
        
        val diffs = (1 until trimmedRr.size).map { abs(trimmedRr[it] - trimmedRr[it - 1]) }
        val diffGt100Count = diffs.count { it > 100.0 }
        val pnn100Ratio = if (diffs.isNotEmpty()) diffGt100Count.toDouble() / diffs.size else 0.0
        val rrMaxMinRatio = if (trimmedRr.isNotEmpty() && trimmedRr.minOrNull()!! > 0.0) {
            trimmedRr.maxOrNull()!! / trimmedRr.minOrNull()!!
        } else {
            1.0
        }
        
        val condSdnn = sdnn > cfg.sdnnLimit
        val condPnn100 = pnn100Ratio > cfg.pnn100Limit
        val condRmssd = rmssd > cfg.rmssdLimit
        val condRatio = rrMaxMinRatio > cfg.ratioLimit
        
        val windowAfibAbnormal = condSdnn && condPnn100 && condRmssd && condRatio
        
        if (windowAfibAbnormal) {
            consecutiveWarningCount++
            if (consecutiveWarningCount >= 3) {
                return hrAlertPrefix + "🚨 【高度节律紊乱/房颤疑似预警】"
            }
        } else {
            consecutiveWarningCount = 0
        }
        
        if (consecutiveWarningCount > 0) {
            return hrAlertPrefix + "⏳ 观测提示: 节律中度扰动 (异常累计滑窗: $consecutiveWarningCount/3)"
        }
        if (prematureIncrement >= 3) {
            return hrAlertPrefix + "⚠️ 【偶发早搏频繁增多提示】"
        }
        if (sdnn > (cfg.sdnnLimit * 0.7) && !windowAfibAbnormal) {
            return hrAlertPrefix + "🍃 【生理性窦性心律不齐】"
        }
        
        return hrAlertPrefix + "✅ 窦性心律平稳"
    }

    // --- 核心：多阶有限状态机及双通道自适应异位心搏过滤通道 ---
    fun processBleRrStream(rrMs: Double, packetHr: Int): Pair<Boolean, Int> {
        val cfg = getAdaptiveThresholds()
        
        // 1. 过滤完全相同的硬件级重复冗余包
        val lastValid = lastValidSinusRr
        if (lastValid != null && abs(rrMs - lastValid) < 0.0001) {
            return Pair(false, 0)
        }
        
        // 2. 物理脉搏与数理间期交叉硬熔断校验（剔除硬件错乱包）
        if (packetHr > 0) {
            val theoryRr = 60000.0 / packetHr
            if (abs(rrMs - theoryRr) > 500.0 && abs(rrMs - theoryRr) > (0.50 * theoryRr)) {
                return Pair(false, 0)
            }
        }
        
        // 3. 提取历史基线及瞬时心率
        val currentBaseHr = 60000.0 / (if (filterHistory.size >= 3) filterHistory.average() else 800.0)
        val localBaseline = if (filterHistory.size >= 3) filterHistory.takeLast(3).sum() / 3.0 else 800.0
        
        // 4. 无 RR 上限二次动态适配逻辑
        val dynamicMaxLimit = minOf(3000.0, maxOf(2000.0, localBaseline * 1.6))
        val dynamicMinLimit = maxOf(300.0, 60000.0 / (currentBaseHr * 2.2))
        
        if (rrMs < dynamicMinLimit || rrMs > dynamicMaxLimit) {
            return Pair(false, 0)
        }
        
        // 5. 动态历史基准采样长度自适应调节
        val dynamicHistoryLen = if (currentBaseHr < 75.0) 8 else 4
        
        // 自适应变异滤波局部阈值
        val adaptiveThreshold = if (currentBaseHr < 120.0) 0.15 else 0.25
        
        if (filterHistory.size >= 3) {
            val localBaseline3 = filterHistory.takeLast(3).sum() / 3.0
            
            // 联合相邻差分突变校验（双向断崖式跃迁）
            var isAbruptDrop = false
            if (rrMs < cfg.prematureRatio * localBaseline3) {
                val lastRaw = lastRawRr
                if (lastRaw != null) {
                    if (rrMs < cfg.prematureRatio * lastRaw) {
                        isAbruptDrop = true
                    }
                } else {
                    isAbruptDrop = true
                }
            }
            
            // 有限状态机流转控制
            if (isAbruptDrop) {
                prematureBeatCount++
                
                if (prematureState in listOf(0, 3, 4)) {
                    prematureState = 1
                } else if (prematureState in listOf(1, 2)) {
                    prematureState = 2
                }
                
                lastRawRr = rrMs
                return Pair(false, 1)
            }
            
            // 多阶恢复期状态转换
            when (prematureState) {
                1 -> {
                    if (rrMs > cfg.compensateRatio * localBaseline3) {
                        prematureState = 3
                        sinusConfirmCounter = 0
                        recoveryAbnormalCounter = 0
                        lastRawRr = rrMs
                        return Pair(false, 0)
                    } else {
                        prematureState = 0
                        lastRawRr = rrMs
                        return Pair(false, 0)
                    }
                }
                2 -> {
                    if (rrMs >= 0.95 * localBaseline3) {
                        prematureState = 3
                        sinusConfirmCounter = 0
                        recoveryAbnormalCounter = 0
                        lastRawRr = rrMs
                        // 允许控制流自然向下滑落至常规路径 B 验证
                    } else {
                        lastRawRr = rrMs
                        return Pair(false, 0)
                    }
                }
                3, 4 -> {
                    if (rrMs in (cfg.prematureRatio * localBaseline3)..(cfg.compensateRatio * localBaseline3)) {
                        sinusConfirmCounter++
                        recoveryAbnormalCounter = 0
                        if (prematureState == 3 && sinusConfirmCounter >= 1) {
                            prematureState = 4
                            sinusConfirmCounter = 0
                        } else if (prematureState == 4 && sinusConfirmCounter >= 2) {
                            prematureState = 0
                        }
                    } else {
                        recoveryAbnormalCounter++
                        sinusConfirmCounter = 0
                        if (recoveryAbnormalCounter >= 2) {
                            prematureState = 2
                            recoveryAbnormalCounter = 0
                        }
                        lastRawRr = rrMs
                        return Pair(false, 0)
                    }
                }
            }
        }
        
        // 路径 B - 常规微小运动毛刺/静电杂波剔除（自适应局部中位数防护）
        if (filterHistory.size >= 3) {
            val localMedian = filterHistory.median()
            if (abs(rrMs - localMedian) > (adaptiveThreshold * localMedian)) {
                lastRawRr = rrMs
                return Pair(false, 0)
            }
        }
        
        lastRawRr = rrMs
        lastValidSinusRr = rrMs
        filterHistory.add(rrMs)
        if (filterHistory.size > dynamicHistoryLen) {
            filterHistory.removeAt(0)
        }
        
        return Pair(true, 0)
    }

    // --- 心跳喂养分析核心 ---
    fun feedRr(rrMs: Double, packetHr: Int): HrvAnalysisResult? {
        val (isValidSinus, pInc) = processBleRrStream(rrMs, packetHr)
        
        windowPrematureTracker.add(pInc)
        if (windowPrematureTracker.size > REQUIRED_WINDOW_SIZE) {
            windowPrematureTracker.removeAt(0)
        }
        
        if (isValidSinus) {
            rrBuffer.add(rrMs)
            if (rrBuffer.size > REQUIRED_WINDOW_SIZE) {
                rrBuffer.removeAt(0)
            }
            
            val currentSize = rrBuffer.size
            if (currentSize >= MIN_WINDOW_SIZE) {
                val trimmedRr: List<Double>
                val windowLabel: String
                if (currentSize < REQUIRED_WINDOW_SIZE) {
                    trimmedRr = ArrayList(rrBuffer)
                    windowLabel = "⏳ 快速引导启动期 [$currentSize/61]"
                } else {
                    trimmedRr = getTrimmedSinusRr(rrBuffer)
                    windowLabel = "🔬 医疗级时序极值裁剪滚动窗"
                }
                
                val timeDomain = calculateHrvTimeDomain(trimmedRr)
                val freqDomain = calculateHrvFrequencyDomain(trimmedRr)
                
                val recentPrematureIncrement = windowPrematureTracker.sum()
                val diagnostic = checkArrhythmiaSafety(
                    trimmedRr = trimmedRr,
                    avgHr = timeDomain.avgHr,
                    sdnn = timeDomain.sdnn,
                    rmssd = timeDomain.rmssd,
                    pnn50 = timeDomain.pnn50,
                    prematureIncrement = recentPrematureIncrement
                )
                
                return HrvAnalysisResult(
                    windowLabel = windowLabel,
                    mode = getAdaptiveThresholds().mode,
                    avgHr = timeDomain.avgHr,
                    sdnn = timeDomain.sdnn,
                    rmssd = timeDomain.rmssd,
                    pnn50 = timeDomain.pnn50,
                    lf = freqDomain.lf,
                    hf = freqDomain.hf,
                    lfHfRatio = freqDomain.lfHfRatio,
                    recentPrematureIncrement = recentPrematureIncrement,
                    totalPrematureCount = prematureBeatCount,
                    diagnosticStatus = diagnostic
                )
            }
        }
        return null
    }
}

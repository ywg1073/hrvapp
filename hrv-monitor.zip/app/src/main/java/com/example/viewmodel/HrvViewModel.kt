package com.example.viewmodel

import android.app.Application
import android.content.Context
import android.content.Intent
import android.content.SharedPreferences
import androidx.core.content.FileProvider
import androidx.lifecycle.AndroidViewModel
import androidx.lifecycle.viewModelScope
import com.example.algorithm.HrvAnalysisResult
import com.example.algorithm.HrvAnalyzer
import com.example.ble.BleConnectionState
import com.example.ble.BleDeviceItem
import com.example.ble.BleHeartRateManager
import com.example.ble.ParsedHrPacket
import com.example.data.AppDatabase
import com.example.data.HrvRecord
import com.example.data.HrvRepository
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.SharingStarted
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.flow.stateIn
import kotlinx.coroutines.launch
import java.io.File
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale

class HrvViewModel(application: Application) : AndroidViewModel(application) {

    private val context = application.applicationContext
    private val prefs: SharedPreferences = context.getSharedPreferences("HrvPrefs", Context.MODE_PRIVATE)

    // --- Repositories and Managers ---
    private val hrvDao = AppDatabase.getDatabase(context).hrvDao()
    private val repository = HrvRepository(hrvDao)
    val bleManager = BleHeartRateManager(context)
    private val hrvAnalyzer = HrvAnalyzer()

    // --- Flow Adapters from BLE Manager ---
    val connectionState: StateFlow<BleConnectionState> = bleManager.connectionState
    val scannedDevices: StateFlow<List<BleDeviceItem>> = bleManager.scannedDevices
    val bleLogs: StateFlow<List<String>> = bleManager.logFlow

    // --- Local DB Live Feed ---
    val savedRecords: StateFlow<List<HrvRecord>> = repository.allRecords
        .stateIn(
            scope = viewModelScope,
            started = SharingStarted.WhileSubscribed(5000),
            initialValue = emptyList()
        )

    // --- Live Monitoring State ---
    private val _isRecording = MutableStateFlow(false)
    val isRecording: StateFlow<Boolean> = _isRecording.asStateFlow()

    private val _currentHeartRate = MutableStateFlow(0)
    val currentHeartRate: StateFlow<Int> = _currentHeartRate.asStateFlow()

    private val _lastAnalysisResult = MutableStateFlow<HrvAnalysisResult?>(null)
    val lastAnalysisResult: StateFlow<HrvAnalysisResult?> = _lastAnalysisResult.asStateFlow()

    private val _sessionProgress = MutableStateFlow(0) // count of valid sinus RRs in active window
    val sessionProgress: StateFlow<Int> = _sessionProgress.asStateFlow()

    private val _sessionResultsList = MutableStateFlow<List<HrvAnalysisResult>>(emptyList())
    val sessionResultsList: StateFlow<List<HrvAnalysisResult>> = _sessionResultsList.asStateFlow()

    private val _totalPrematureCount = MutableStateFlow(0)
    val totalPrematureCount: StateFlow<Int> = _totalPrematureCount.asStateFlow()

    // --- Formatted Log Content Buffer for Active Session ---
    private val sessionLogBuilder = StringBuilder()
    private var sessionStartTime: Long = 0L

    init {
        // Load global state (cumulative premature beat count)
        val savedCount = prefs.getInt("total_premature_beat_count", 0)
        _totalPrematureCount.value = savedCount
        hrvAnalyzer.prematureBeatCount = savedCount

        // Listen to live BLE packet emissions
        viewModelScope.launch {
            bleManager.hrDataFlow.collect { packet ->
                if (packet != null) {
                    processIncomingPacket(packet)
                }
            }
        }
    }

    // --- BLE Actions wrapper ---
    fun startBleScan() {
        bleManager.startScan()
    }

    fun stopBleScan() {
        bleManager.stopScan()
    }

    fun connectDevice(deviceItem: BleDeviceItem) {
        bleManager.connectToDevice(deviceItem.device)
    }

    fun disconnectDevice() {
        bleManager.disconnect()
        if (_isRecording.value) {
            stopAndSaveSession()
        }
    }

    // --- Session Control ---
    fun startSession() {
        if (_isRecording.value) return
        
        hrvAnalyzer.reset()
        // restore historical accumulated premature count as base
        hrvAnalyzer.prematureBeatCount = _totalPrematureCount.value
        
        _sessionResultsList.value = emptyList()
        _lastAnalysisResult.value = null
        _sessionProgress.value = 0
        
        sessionLogBuilder.clear()
        sessionLogBuilder.append("================================================================\n")
        sessionLogBuilder.append("📡 HRV 实时全参数监测分析日志启动\n")
        sessionLogBuilder.append("开始时间: ${getFormattedDateTime(System.currentTimeMillis())}\n")
        sessionLogBuilder.append("================================================================\n\n")

        sessionStartTime = System.currentTimeMillis()
        _isRecording.value = true
        bleManager.addLog("🎬 HRV 监测录制已开始")
    }

    fun stopAndSaveSession() {
        if (!_isRecording.value) return
        _isRecording.value = false
        bleManager.addLog("⏹️ HRV 监测录制已停止")

        val results = _sessionResultsList.value
        val endTime = System.currentTimeMillis()

        if (results.isEmpty()) {
            bleManager.addLog("⚠️ 记录未保存: 未收集到足够的窦性心搏滑窗分析数据(需至少30个有效心搏)。")
            return
        }

        // Aggregate session-wide statistics
        val avgHr = results.map { it.avgHr }.average()
        val avgSdnn = results.map { it.sdnn }.average()
        val avgRmssd = results.map { it.rmssd }.average()
        val avgPnn50 = results.map { it.pnn50 }.average()
        val avgLf = results.map { it.lf }.average()
        val avgHf = results.map { it.hf }.average()
        val avgLfHf = if (avgHf > 0) avgLf / avgHf else 0.0
        val finalPrematureCount = results.lastOrNull()?.totalPrematureCount ?: _totalPrematureCount.value
        
        // Save back global state if updated
        if (finalPrematureCount != _totalPrematureCount.value) {
            _totalPrematureCount.value = finalPrematureCount
            prefs.edit().putInt("total_premature_beat_count", finalPrematureCount).apply()
        }

        val lastDiag = results.lastOrNull()?.diagnosticStatus ?: "✅ 窦性心律平稳"

        // Append final Hour-level / Session-level Summary Report (mimicking Python's Summary text output)
        sessionLogBuilder.append("\n\n")
        sessionLogBuilder.append("================================================================\n")
        sessionLogBuilder.append("📊 [📊 HRV 全程时频趋势汇总分析报告]\n")
        sessionLogBuilder.append("结束时间: ${getFormattedDateTime(endTime)}\n")
        sessionLogBuilder.append("监测总历时: ${formatDuration(endTime - sessionStartTime)}\n")
        sessionLogBuilder.append("平均心率: ${String.format("%.2f", avgHr)} bpm\n")
        sessionLogBuilder.append("平均 HRV(SDNN): ${String.format("%.2f", avgSdnn)} ms\n")
        sessionLogBuilder.append("平均 RMSSD(抗疲劳): ${String.format("%.2f", avgRmssd)} ms\n")
        sessionLogBuilder.append("平均 pNN50: ${String.format("%.2f", avgPnn50)} %\n")
        sessionLogBuilder.append("平均 LF (ms²): ${String.format("%.2f", avgLf)}\n")
        sessionLogBuilder.append("平均 HF (ms²): ${String.format("%.2f", avgHf)}\n")
        sessionLogBuilder.append("平均 LF/HF 植物神经张力比: ${String.format("%.2f", avgLfHf)}\n")
        sessionLogBuilder.append("本会话期间总早搏数: ${finalPrematureCount - _totalPrematureCount.value} 次\n")
        sessionLogBuilder.append("累计历史早搏基数: $finalPrematureCount 次\n")
        sessionLogBuilder.append("会话最后诊断: $lastDiag\n")
        sessionLogBuilder.append("================================================================\n")

        val newRecord = HrvRecord(
            startTime = sessionStartTime,
            endTime = endTime,
            avgHr = avgHr,
            sdnn = avgSdnn,
            rmssd = avgRmssd,
            pnn50 = avgPnn50,
            lf = avgLf,
            hf = avgHf,
            lfHf = avgLfHf,
            prematureCount = finalPrematureCount - _totalPrematureCount.value,
            diagnostic = lastDiag,
            logContent = sessionLogBuilder.toString()
        )

        viewModelScope.launch {
            val recordId = repository.insertRecord(newRecord)
            bleManager.addLog("💾 HRV 监测数据已成功归档，记录 ID: $recordId")
        }
    }

    // --- Packet Processor ---
    private fun processIncomingPacket(packet: ParsedHrPacket) {
        _currentHeartRate.value = packet.heartRate
        
        if (!_isRecording.value) return

        // Feed each raw RR interval sequentially to our algorithm engine
        for (rrMs in packet.rrIntervals) {
            val result = hrvAnalyzer.feedRr(rrMs, packet.heartRate)
            
            // Sync progress counter (accumulating sinus heartbeats)
            _sessionProgress.value = hrvAnalyzer.rrBuffer.size

            if (result != null) {
                // We got a rolling window output!
                _lastAnalysisResult.value = result
                _sessionResultsList.value = _sessionResultsList.value + result

                // Save historical premature beat increments if they occur
                if (result.totalPrematureCount != _totalPrematureCount.value) {
                    _totalPrematureCount.value = result.totalPrematureCount
                    prefs.edit().putInt("total_premature_beat_count", result.totalPrematureCount).apply()
                }

                // Format standard log entry line (matches python log format exactly)
                val logLine = String.format(
                    "[%s] HR: %6.2f | SDNN: %6.2f | RMSSD: %6.2f | LF: %7.1f | HF: %7.1f | LF/HF: %5.2f | 历史总早搏: %d次 | 诊断: %s\n",
                    getFormattedDateTimeShort(result.timestamp),
                    result.avgHr,
                    result.sdnn,
                    result.rmssd,
                    result.lf,
                    result.hf,
                    result.lfHfRatio,
                    result.totalPrematureCount,
                    result.diagnosticStatus
                )
                sessionLogBuilder.append(logLine)
                bleManager.addLog("📈 滑窗更新: 心率 ${String.format("%.1f", result.avgHr)} | SDNN: ${String.format("%.1f", result.sdnn)}")
            }
        }
    }

    // --- DB Records operations ---
    fun deleteRecord(record: HrvRecord) {
        viewModelScope.launch {
            repository.deleteRecord(record)
            bleManager.addLog("🗑️ 已删除 HRV 记录: ${getFormattedDateTime(record.startTime)}")
        }
    }

    fun deleteRecordById(id: Int) {
        viewModelScope.launch {
            repository.deleteRecordById(id)
        }
    }

    // --- Sharing and File export Engine ---
    fun exportAndShareRecord(context: Context, record: HrvRecord) {
        try {
            val formattedDate = SimpleDateFormat("yyyyMMdd_HHmmss", Locale.getDefault()).format(Date(record.startTime))
            val fileName = "HRV_Advanced_Holter_Log_$formattedDate.txt"
            
            val file = File(context.cacheDir, fileName)
            file.writeText(record.logContent)

            val uri = FileProvider.getUriForFile(
                context,
                "${context.packageName}.fileprovider",
                file
            )

            val intent = Intent(Intent.ACTION_SEND).apply {
                type = "text/plain"
                putExtra(Intent.EXTRA_SUBJECT, "HRV 生态生理多参监测数据导出报告")
                putExtra(Intent.EXTRA_STREAM, uri)
                addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION)
            }

            val chooser = Intent.createChooser(intent, "分享 HRV 全维导出日志 (.txt)")
            chooser.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
            context.startActivity(chooser)
        } catch (e: Exception) {
            bleManager.addLog("❌ 导出分享失败: ${e.localizedMessage}")
        }
    }

    // --- Formatting Utility ---
    private fun getFormattedDateTime(timestamp: Long): String {
        val sdf = SimpleDateFormat("yyyy-MM-dd HH:mm:ss", Locale.getDefault())
        return sdf.format(Date(timestamp))
    }

    private fun getFormattedDateTimeShort(timestamp: Long): String {
        val sdf = SimpleDateFormat("HH:mm:ss", Locale.getDefault())
        return sdf.format(Date(timestamp))
    }

    private fun formatDuration(millis: Long): String {
        val seconds = (millis / 1000) % 60
        val minutes = (millis / (1000 * 60)) % 60
        val hours = (millis / (1000 * 60 * 60))
        return if (hours > 0) {
            String.format("%d小时 %02d分 %02d秒", hours, minutes, seconds)
        } else {
            String.format("%02d分 %02d秒", minutes, seconds)
        }
    }
}

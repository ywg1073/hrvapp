package com.example

import android.annotation.SuppressLint
import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.activity.enableEdgeToEdge
import androidx.activity.result.contract.ActivityResultContracts
import androidx.activity.viewModels
import androidx.compose.animation.AnimatedVisibility
import androidx.compose.animation.core.Animatable
import androidx.compose.animation.core.FastOutSlowInEasing
import androidx.compose.animation.core.LinearEasing
import androidx.compose.animation.core.RepeatMode
import androidx.compose.animation.core.animateFloat
import androidx.compose.animation.core.infiniteRepeatable
import androidx.compose.animation.core.rememberInfiniteTransition
import androidx.compose.animation.core.tween
import androidx.compose.foundation.BorderStroke
import androidx.compose.foundation.Canvas
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.WindowInsets
import androidx.compose.foundation.layout.asPaddingValues
import androidx.compose.foundation.layout.fillMaxHeight
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.navigationBars
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.filled.List
import androidx.compose.material.icons.filled.Bluetooth
import androidx.compose.material.icons.filled.BluetoothConnected
import androidx.compose.material.icons.filled.BluetoothSearching
import androidx.compose.material.icons.filled.Delete
import androidx.compose.material.icons.filled.Favorite
import androidx.compose.material.icons.filled.History
import androidx.compose.material.icons.filled.Info
import androidx.compose.material.icons.filled.PlayArrow
import androidx.compose.material.icons.filled.Refresh
import androidx.compose.material.icons.filled.Share
import androidx.compose.material.icons.filled.Stop
import androidx.compose.material.icons.filled.Warning
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.CircularProgressIndicator
import androidx.compose.material3.ExperimentalMaterial3Api
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.LinearProgressIndicator
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.NavigationBar
import androidx.compose.material3.NavigationBarItem
import androidx.compose.material3.NavigationBarItemDefaults
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.Scaffold
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.material3.TopAppBar
import androidx.compose.material3.TopAppBarDefaults
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.collectAsState
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.draw.scale
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.Path
import androidx.compose.ui.graphics.drawscope.Stroke
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.font.FontFamily
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.lifecycle.compose.collectAsStateWithLifecycle
import com.example.algorithm.HrvAnalysisResult
import com.example.ble.BleConnectionState
import com.example.ble.BleDeviceItem
import com.example.data.HrvRecord
import com.example.ui.theme.AutonomicViolet
import com.example.ui.theme.AutonomicVioletLight
import com.example.ui.theme.CarbonBlack
import com.example.ui.theme.CarbonBorder
import com.example.ui.theme.CarbonSlateCard
import com.example.ui.theme.CarbonSlateDark
import com.example.ui.theme.CyberEmerald
import com.example.ui.theme.CyberEmeraldDark
import com.example.ui.theme.MyApplicationTheme
import com.example.ui.theme.StressAmber
import com.example.ui.theme.TextGray
import com.example.ui.theme.TextWhite
import com.example.ui.theme.WarningCrimson
import com.example.viewmodel.HrvViewModel
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale

class MainActivity : ComponentActivity() {

    private val viewModel: HrvViewModel by viewModels()

    // Activity level standard launcher for permissions
    private val requestPermissionLauncher = registerForActivityResult(
        ActivityResultContracts.RequestMultiplePermissions()
    ) { permissions ->
        val allGranted = permissions.entries.all { it.value }
        if (allGranted) {
            viewModel.bleManager.addLog("✅ BLE与高精度定位权限已全部开启！")
            viewModel.startBleScan()
        } else {
            viewModel.bleManager.addLog("❌ 授权失败。请确保蓝牙与定位相关权限已全部在系统设置中启用。")
        }
    }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        enableEdgeToEdge()

        setContent {
            MyApplicationTheme {
                MainScreen(viewModel = viewModel, onRequestPermissions = {
                    requestPermissionLauncher.launch(
                        viewModel.bleManager.getRequiredPermissionsList().toTypedArray()
                    )
                })
            }
        }
    }
}

enum class ActiveTab {
    MONITOR,
    RECORDS
}

@SuppressLint("UnusedContentLambdaTargetStateParameter")
@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun MainScreen(
    viewModel: HrvViewModel,
    onRequestPermissions: () -> Unit
) {
    var activeTab by remember { mutableStateOf(ActiveTab.MONITOR) }
    var showScanDialog by remember { mutableStateOf(false) }

    val connectionState by viewModel.connectionState.collectAsStateWithLifecycle()
    val scannedDevices by viewModel.scannedDevices.collectAsStateWithLifecycle()

    // Automatically trigger permission check & scanning if scan is requested
    LaunchedEffect(connectionState) {
        if (connectionState == BleConnectionState.SCANNING) {
            showScanDialog = true
        }
    }

    Scaffold(
        topBar = {
            TopAppBar(
                title = {
                    Column {
                        Text(
                            text = "HRV 智能心电监测仪",
                            fontSize = 18.sp,
                            fontWeight = FontWeight.Bold,
                            color = TextWhite
                        )
                        Text(
                            text = "医用级自适应时频双通道 Holter 引擎",
                            fontSize = 11.sp,
                            color = TextGray
                        )
                    }
                },
                actions = {
                    ConnectionBadge(
                        state = connectionState,
                        onScanClick = {
                            if (viewModel.bleManager.hasRequiredPermissions()) {
                                viewModel.startBleScan()
                            } else {
                                onRequestPermissions()
                            }
                        },
                        onDisconnectClick = {
                            viewModel.disconnectDevice()
                        }
                    )
                },
                colors = TopAppBarDefaults.topAppBarColors(
                    containerColor = MaterialTheme.colorScheme.background,
                    titleContentColor = TextWhite
                )
            )
        },
        bottomBar = {
            NavigationBar(
                containerColor = CarbonSlateDark,
                windowInsets = WindowInsets.navigationBars
            ) {
                NavigationBarItem(
                    selected = activeTab == ActiveTab.MONITOR,
                    onClick = { activeTab = ActiveTab.MONITOR },
                    icon = { Icon(Icons.Default.Favorite, contentDescription = "实时监护") },
                    label = { Text("实时监护", fontWeight = FontWeight.Medium) },
                    colors = NavigationBarItemDefaults.colors(
                        selectedIconColor = CyberEmerald,
                        unselectedIconColor = TextGray,
                        selectedTextColor = CyberEmerald,
                        unselectedTextColor = TextGray,
                        indicatorColor = CarbonSlateCard
                    )
                )
                NavigationBarItem(
                    selected = activeTab == ActiveTab.RECORDS,
                    onClick = { activeTab = ActiveTab.RECORDS },
                    icon = { Icon(Icons.Default.History, contentDescription = "数据记录") },
                    label = { Text("数据记录", fontWeight = FontWeight.Medium) },
                    colors = NavigationBarItemDefaults.colors(
                        selectedIconColor = CyberEmerald,
                        unselectedIconColor = TextGray,
                        selectedTextColor = CyberEmerald,
                        unselectedTextColor = TextGray,
                        indicatorColor = CarbonSlateCard
                    )
                )
            }
        }
    ) { innerPadding ->
        Box(
            modifier = Modifier
                .fillMaxSize()
                .background(MaterialTheme.colorScheme.background)
                .padding(innerPadding)
        ) {
            when (activeTab) {
                ActiveTab.MONITOR -> {
                    MonitorTabContent(
                        viewModel = viewModel,
                        onTriggerScan = {
                            if (viewModel.bleManager.hasRequiredPermissions()) {
                                viewModel.startBleScan()
                            } else {
                                onRequestPermissions()
                            }
                        }
                    )
                }
                ActiveTab.RECORDS -> {
                    RecordsTabContent(viewModel = viewModel)
                }
            }

            // Custom stylish Scanning Overlay
            if (showScanDialog) {
                ScanningDialog(
                    devices = scannedDevices,
                    onDeviceSelected = { device ->
                        viewModel.connectDevice(device)
                        showScanDialog = false
                    },
                    onDismiss = {
                        viewModel.stopBleScan()
                        showScanDialog = false
                    },
                    isScanning = connectionState == BleConnectionState.SCANNING,
                    onRescan = {
                        viewModel.startBleScan()
                    }
                )
            }
        }
    }
}

// --- Connections Badge Indicator ---
@Composable
fun ConnectionBadge(
    state: BleConnectionState,
    onScanClick: () -> Unit,
    onDisconnectClick: () -> Unit
) {
    val (text, color) = when (state) {
        BleConnectionState.DISCONNECTED -> "未连接" to Color.Gray
        BleConnectionState.SCANNING -> "检索中..." to StressAmber
        BleConnectionState.CONNECTING -> "握手中..." to StressAmber
        BleConnectionState.CONNECTED -> "已连接" to CyberEmeraldDark
        BleConnectionState.DISCOVERING_SERVICES -> "服务发现" to AutonomicViolet
        BleConnectionState.SUBSCRIBED -> "同步中" to CyberEmerald
    }

    Row(
        verticalAlignment = Alignment.CenterVertically,
        modifier = Modifier.padding(end = 12.dp)
    ) {
        Surface(
            color = color.copy(alpha = 0.15f),
            shape = RoundedCornerShape(12.dp),
            border = BorderStroke(1.dp, color.copy(alpha = 0.5f)),
            modifier = Modifier.padding(end = 8.dp)
        ) {
            Row(
                verticalAlignment = Alignment.CenterVertically,
                modifier = Modifier.padding(horizontal = 8.dp, vertical = 4.dp)
            ) {
                Box(
                    modifier = Modifier
                        .size(6.dp)
                        .background(color, CircleShape)
                )
                Spacer(modifier = Modifier.width(6.dp))
                Text(
                    text = text,
                    color = color,
                    fontSize = 11.sp,
                    fontWeight = FontWeight.Bold
                )
            }
        }

        if (state == BleConnectionState.DISCONNECTED) {
            IconButton(
                onClick = onScanClick,
                modifier = Modifier
                    .size(34.dp)
                    .background(CyberEmerald.copy(alpha = 0.1f), CircleShape)
                    .border(1.dp, CyberEmerald.copy(alpha = 0.3f), CircleShape)
            ) {
                Icon(
                    Icons.Default.Bluetooth,
                    contentDescription = "扫描设备",
                    tint = CyberEmerald,
                    modifier = Modifier.size(18.dp)
                )
            }
        } else {
            IconButton(
                onClick = onDisconnectClick,
                modifier = Modifier
                    .size(34.dp)
                    .background(WarningCrimson.copy(alpha = 0.1f), CircleShape)
                    .border(1.dp, WarningCrimson.copy(alpha = 0.3f), CircleShape)
            ) {
                Icon(
                    Icons.Default.Stop,
                    contentDescription = "断开设备",
                    tint = WarningCrimson,
                    modifier = Modifier.size(18.dp)
                )
            }
        }
    }
}

// --- Live Monitor Screen ---
@Composable
fun MonitorTabContent(
    viewModel: HrvViewModel,
    onTriggerScan: () -> Unit
) {
    val connectionState by viewModel.connectionState.collectAsStateWithLifecycle()
    val isRecording by viewModel.isRecording.collectAsStateWithLifecycle()
    val heartRate by viewModel.currentHeartRate.collectAsStateWithLifecycle()
    val lastResult by viewModel.lastAnalysisResult.collectAsStateWithLifecycle()
    val sessionProgress by viewModel.sessionProgress.collectAsStateWithLifecycle()
    val totalPrematures by viewModel.totalPrematureCount.collectAsStateWithLifecycle()
    val logs by viewModel.bleLogs.collectAsStateWithLifecycle()

    val scrollState = rememberScrollState()

    Column(
        modifier = Modifier
            .fillMaxSize()
            .verticalScroll(scrollState)
            .padding(16.dp),
        verticalArrangement = Arrangement.spacedBy(16.dp)
    ) {
        // Hero Card: Live Heart Rate & Pulsing visualizer
        HeartRateHeroCard(
            heartRate = heartRate,
            connectionState = connectionState,
            totalPrematures = totalPrematures,
            lastResult = lastResult,
            onTriggerScan = onTriggerScan
        )

        // Recording Session Controls Card
        SessionControlCard(
            connectionState = connectionState,
            isRecording = isRecording,
            sessionProgress = sessionProgress,
            lastResult = lastResult,
            onStartSession = { viewModel.startSession() },
            onStopSession = { viewModel.stopAndSaveSession() }
        )

        // Diagnostic Status card (Highlight Banner)
        lastResult?.let { result ->
            DiagnosticStatusCard(result = result)
        }

        // 2-Column Advanced HRV Metrics Grid
        HrvMetricsGrid(result = lastResult)

        // Terminal Terminal Terminal Logs Console
        LogsConsoleCard(logs = logs)
    }
}

// --- Heart Rate Hero Card ---
@Composable
fun HeartRateHeroCard(
    heartRate: Int,
    connectionState: BleConnectionState,
    totalPrematures: Int,
    lastResult: HrvAnalysisResult?,
    onTriggerScan: () -> Unit
) {
    // Elegant background ECG line sketch
    val pulseDurationMs = if (heartRate > 30) (60000 / heartRate) else 800
    val infiniteTransition = rememberInfiniteTransition(label = "pulse")
    val scale by infiniteTransition.animateFloat(
        initialValue = 1.0f,
        targetValue = 1.15f,
        animationSpec = infiniteRepeatable(
            animation = tween(pulseDurationMs / 2, easing = FastOutSlowInEasing),
            repeatMode = RepeatMode.Reverse
        ),
        label = "pulseScale"
    )

    Card(
        modifier = Modifier.fillMaxWidth(),
        colors = CardDefaults.cardColors(containerColor = CarbonSlateDark),
        border = BorderStroke(1.dp, CarbonBorder),
        shape = RoundedCornerShape(16.dp)
    ) {
        Box(
            modifier = Modifier
                .fillMaxWidth()
                .padding(16.dp)
        ) {
            // Background ECG Sweep wave
            EcgSweepBackground(
                modifier = Modifier
                    .fillMaxWidth()
                    .height(100.dp)
                    .align(Alignment.BottomCenter)
            )

            Column(
                modifier = Modifier.fillMaxWidth(),
                horizontalAlignment = Alignment.CenterHorizontally
            ) {
                Text(
                    text = lastResult?.mode ?: "自适应生理模式侦测中",
                    fontSize = 12.sp,
                    color = AutonomicVioletLight,
                    fontWeight = FontWeight.Bold,
                    modifier = Modifier.padding(bottom = 8.dp)
                )

                Row(
                    verticalAlignment = Alignment.CenterVertically,
                    horizontalArrangement = Arrangement.Center,
                    modifier = Modifier.fillMaxWidth()
                ) {
                    // Pulsing Heart Icon
                    Icon(
                        imageVector = Icons.Default.Favorite,
                        contentDescription = "心跳波形",
                        tint = if (connectionState == BleConnectionState.SUBSCRIBED) CyberEmerald else Color.Gray,
                        modifier = Modifier
                            .size(48.dp)
                            .scale(if (connectionState == BleConnectionState.SUBSCRIBED) scale else 1.0f)
                    )
                    Spacer(modifier = Modifier.width(16.dp))
                    
                    // Large HR typography
                    Column {
                        Row(verticalAlignment = Alignment.Bottom) {
                            Text(
                                text = if (connectionState == BleConnectionState.SUBSCRIBED && heartRate > 0) "$heartRate" else "--",
                                fontSize = 54.sp,
                                fontFamily = FontFamily.Monospace,
                                fontWeight = FontWeight.Black,
                                color = TextWhite
                            )
                            Text(
                                text = "BPM",
                                fontSize = 12.sp,
                                fontWeight = FontWeight.Bold,
                                color = TextGray,
                                modifier = Modifier.padding(bottom = 10.dp, start = 4.dp)
                            )
                        }
                    }
                }

                Spacer(modifier = Modifier.height(12.dp))

                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.SpaceEvenly
                ) {
                    Column(horizontalAlignment = Alignment.CenterHorizontally) {
                        Text("累计总早搏", fontSize = 11.sp, color = TextGray)
                        Text(
                            "$totalPrematures 次",
                            fontSize = 16.sp,
                            fontWeight = FontWeight.Bold,
                            color = if (totalPrematures > 0) WarningCrimson else CyberEmerald
                        )
                    }
                    Box(
                        modifier = Modifier
                            .width(1.dp)
                            .height(30.dp)
                            .background(CarbonBorder)
                    )
                    Column(horizontalAlignment = Alignment.CenterHorizontally) {
                        Text("滑窗状态", fontSize = 11.sp, color = TextGray)
                        Text(
                            lastResult?.windowLabel?.substringBefore("[") ?: "心搏蓄水中",
                            fontSize = 13.sp,
                            fontWeight = FontWeight.Bold,
                            color = TextWhite,
                            maxLines = 1,
                            overflow = TextOverflow.Ellipsis
                        )
                    }
                }

                if (connectionState == BleConnectionState.DISCONNECTED) {
                    Spacer(modifier = Modifier.height(16.dp))
                    Button(
                        onClick = onTriggerScan,
                        colors = ButtonDefaults.buttonColors(containerColor = CyberEmerald),
                        shape = RoundedCornerShape(8.dp),
                        modifier = Modifier.fillMaxWidth(0.8f)
                    ) {
                        Icon(Icons.Default.BluetoothSearching, contentDescription = null)
                        Spacer(modifier = Modifier.width(8.dp))
                        Text("全网检索心率带设备", fontWeight = FontWeight.Bold, color = CarbonBlack)
                    }
                }
            }
        }
    }
}

// --- Background ECG Line simulation ---
@Composable
fun EcgSweepBackground(modifier: Modifier = Modifier) {
    val color = CyberEmerald.copy(alpha = 0.08f)
    Canvas(modifier = modifier) {
        val width = size.width
        val height = size.height
        val path = Path()
        path.moveTo(0f, height * 0.5f)
        
        var x = 0f
        val step = 10f
        var index = 0
        while (x < width) {
            val y = when (index % 25) {
                0 -> height * 0.5f
                12 -> height * 0.2f  // P wave
                13 -> height * 0.5f
                15 -> height * 0.7f  // Q wave
                16 -> height * 0.1f  // R wave peak
                17 -> height * 0.9f  // S wave dip
                18 -> height * 0.5f
                21 -> height * 0.35f // T wave
                22 -> height * 0.5f
                else -> height * 0.5f
            }
            path.lineTo(x, y)
            x += step
            index++
        }
        drawPath(
            path = path,
            color = color,
            style = Stroke(width = 2.dp.toPx())
        )
    }
}

// --- Session Control Card ---
@Composable
fun SessionControlCard(
    connectionState: BleConnectionState,
    isRecording: Boolean,
    sessionProgress: Int,
    lastResult: HrvAnalysisResult?,
    onStartSession: () -> Unit,
    onStopSession: () -> Unit
) {
    Card(
        modifier = Modifier.fillMaxWidth(),
        colors = CardDefaults.cardColors(containerColor = CarbonSlateDark),
        border = BorderStroke(1.dp, CarbonBorder),
        shape = RoundedCornerShape(16.dp)
    ) {
        Column(
            modifier = Modifier
                .fillMaxWidth()
                .padding(16.dp),
            verticalArrangement = Arrangement.spacedBy(12.dp)
        ) {
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
            ) {
                Row(verticalAlignment = Alignment.CenterVertically) {
                    Box(
                        modifier = Modifier
                            .size(8.dp)
                            .background(
                                if (isRecording) WarningCrimson else Color.Gray,
                                CircleShape
                            )
                    )
                    Spacer(modifier = Modifier.width(8.dp))
                    Text(
                        text = if (isRecording) "监测录制中..." else "会话未启动",
                        fontSize = 14.sp,
                        fontWeight = FontWeight.Bold,
                        color = TextWhite
                    )
                }

                if (isRecording) {
                    Text(
                        text = lastResult?.windowLabel ?: "纯净心搏蓄水 [$sessionProgress/30]",
                        fontSize = 11.sp,
                        color = StressAmber,
                        fontWeight = FontWeight.Medium
                    )
                }
            }

            // Buffering progress bar (before window can be computed)
            if (isRecording && sessionProgress < 30) {
                Column(modifier = Modifier.fillMaxWidth()) {
                    LinearProgressIndicator(
                        progress = { sessionProgress.toFloat() / 30f },
                        modifier = Modifier
                            .fillMaxWidth()
                            .height(6.dp)
                            .clip(RoundedCornerShape(3.dp)),
                        color = StressAmber,
                        trackColor = CarbonBorder
                    )
                    Spacer(modifier = Modifier.height(4.dp))
                    Text(
                        text = "正在为双通道时频分析算法蓄水灌注纯净心搏数据 (进度: $sessionProgress/30)",
                        fontSize = 10.sp,
                        color = TextGray
                    )
                }
            }

            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.spacedBy(12.dp)
            ) {
                if (!isRecording) {
                    Button(
                        onClick = onStartSession,
                        enabled = connectionState == BleConnectionState.SUBSCRIBED,
                        colors = ButtonDefaults.buttonColors(
                            containerColor = CyberEmerald,
                            disabledContainerColor = Color.Gray.copy(alpha = 0.2f)
                        ),
                        shape = RoundedCornerShape(8.dp),
                        modifier = Modifier.weight(1f)
                    ) {
                        Icon(
                            Icons.Default.PlayArrow,
                            contentDescription = null,
                            tint = if (connectionState == BleConnectionState.SUBSCRIBED) CarbonBlack else TextGray
                        )
                        Spacer(modifier = Modifier.width(8.dp))
                        Text(
                            "开始记录监测",
                            fontWeight = FontWeight.Bold,
                            color = if (connectionState == BleConnectionState.SUBSCRIBED) CarbonBlack else TextGray
                        )
                    }
                } else {
                    Button(
                        onClick = onStopSession,
                        colors = ButtonDefaults.buttonColors(containerColor = WarningCrimson),
                        shape = RoundedCornerShape(8.dp),
                        modifier = Modifier.weight(1f)
                    ) {
                        Icon(Icons.Default.Stop, contentDescription = null, tint = TextWhite)
                        Spacer(modifier = Modifier.width(8.dp))
                        Text("停止并保存归档", fontWeight = FontWeight.Bold, color = TextWhite)
                    }
                }
            }
        }
    }
}

// --- Diagnostic Status Card ---
@Composable
fun DiagnosticStatusCard(result: HrvAnalysisResult) {
    val isAbnormal = result.diagnosticStatus.contains("🚨") || result.diagnosticStatus.contains("⚠️")
    val isModerate = result.diagnosticStatus.contains("⏳") || result.diagnosticStatus.contains("⚠️")
    val color = when {
        isAbnormal -> WarningCrimson
        isModerate -> StressAmber
        else -> CyberEmerald
    }

    Card(
        modifier = Modifier.fillMaxWidth(),
        colors = CardDefaults.cardColors(containerColor = color.copy(alpha = 0.12f)),
        border = BorderStroke(1.dp, color.copy(alpha = 0.4f)),
        shape = RoundedCornerShape(12.dp)
    ) {
        Row(
            modifier = Modifier
                .fillMaxWidth()
                .padding(14.dp),
            verticalAlignment = Alignment.CenterVertically
        ) {
            Icon(
                imageVector = if (isAbnormal) Icons.Default.Warning else Icons.Default.Info,
                contentDescription = null,
                tint = color,
                modifier = Modifier.size(24.dp)
            )
            Spacer(modifier = Modifier.width(12.dp))
            Column {
                Text(
                    text = "系统分级诊断状态反馈",
                    fontSize = 11.sp,
                    color = TextGray
                )
                Text(
                    text = result.diagnosticStatus,
                    fontSize = 14.sp,
                    fontWeight = FontWeight.Bold,
                    color = color
                )
            }
        }
    }
}

// --- 2-Column HRV Metrics Grid ---
@Composable
fun HrvMetricsGrid(result: HrvAnalysisResult?) {
    Column(
        modifier = Modifier.fillMaxWidth(),
        verticalArrangement = Arrangement.spacedBy(10.dp)
    ) {
        Row(
            modifier = Modifier.fillMaxWidth(),
            horizontalArrangement = Arrangement.spacedBy(10.dp)
        ) {
            MetricItemCard(
                label = "SDNN (抗压张力)",
                value = if (result != null) String.format("%.1f ms", result.sdnn) else "--",
                desc = "评估植物神经总体抗压调节能力",
                accentColor = CyberEmerald,
                modifier = Modifier.weight(1f)
            )
            MetricItemCard(
                label = "RMSSD (疲劳恢复)",
                value = if (result != null) String.format("%.1f ms", result.rmssd) else "--",
                desc = "代表迷走神经兴奋及心脏调节活性",
                accentColor = AutonomicViolet,
                modifier = Modifier.weight(1f)
            )
        }

        Row(
            modifier = Modifier.fillMaxWidth(),
            horizontalArrangement = Arrangement.spacedBy(10.dp)
        ) {
            MetricItemCard(
                label = "LF (交感神经能量)",
                value = if (result != null) String.format("%.1f ms²", result.lf) else "--",
                desc = "交感活动度，高值提示隐性紧张",
                accentColor = StressAmber,
                modifier = Modifier.weight(1f)
            )
            MetricItemCard(
                label = "HF (迷走神经能量)",
                value = if (result != null) String.format("%.1f ms²", result.hf) else "--",
                desc = "副交感活性，代表休息睡眠修复度",
                accentColor = AutonomicVioletLight,
                modifier = Modifier.weight(1f)
            )
        }

        Row(
            modifier = Modifier.fillMaxWidth(),
            horizontalArrangement = Arrangement.spacedBy(10.dp)
        ) {
            MetricItemCard(
                label = "LF/HF 植物神经比值",
                value = if (result != null) String.format("%.2f", result.lfHfRatio) else "--",
                desc = "紧张压力指数 (＞2.0 提示隐性高度疲劳)",
                accentColor = if (result != null && result.lfHfRatio > 2.0) WarningCrimson else CyberEmerald,
                modifier = Modifier.weight(1f)
            )
            MetricItemCard(
                label = "pNN50 副交感指数",
                value = if (result != null) String.format("%.1f %%", result.pnn50) else "--",
                desc = "相邻差值大于50ms占比百分比",
                accentColor = AutonomicVioletLight,
                modifier = Modifier.weight(1f)
            )
        }
    }
}

@Composable
fun MetricItemCard(
    label: String,
    value: String,
    desc: String,
    accentColor: Color,
    modifier: Modifier = Modifier
) {
    Card(
        modifier = modifier,
        colors = CardDefaults.cardColors(containerColor = CarbonSlateDark),
        border = BorderStroke(1.dp, CarbonBorder),
        shape = RoundedCornerShape(12.dp)
    ) {
        Column(
            modifier = Modifier
                .fillMaxWidth()
                .padding(12.dp)
        ) {
            Text(
                text = label,
                fontSize = 11.sp,
                fontWeight = FontWeight.Bold,
                color = TextGray
            )
            Spacer(modifier = Modifier.height(4.dp))
            Text(
                text = value,
                fontSize = 20.sp,
                fontFamily = FontFamily.Monospace,
                fontWeight = FontWeight.Black,
                color = accentColor
            )
            Spacer(modifier = Modifier.height(4.dp))
            Text(
                text = desc,
                fontSize = 9.sp,
                color = TextGray,
                lineHeight = 12.sp,
                maxLines = 2,
                overflow = TextOverflow.Ellipsis
            )
        }
    }
}

// --- Terminal Logs Console Card ---
@Composable
fun LogsConsoleCard(logs: List<String>) {
    Card(
        modifier = Modifier.fillMaxWidth(),
        colors = CardDefaults.cardColors(containerColor = Color.Black),
        border = BorderStroke(1.dp, CarbonBorder),
        shape = RoundedCornerShape(12.dp)
    ) {
        Column(
            modifier = Modifier
                .fillMaxWidth()
                .padding(12.dp)
        ) {
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
            ) {
                Row(verticalAlignment = Alignment.CenterVertically) {
                    Box(
                        modifier = Modifier
                            .size(6.dp)
                            .background(CyberEmerald, CircleShape)
                    )
                    Spacer(modifier = Modifier.width(6.dp))
                    Text(
                        "系统内核算法实时终端",
                        fontSize = 11.sp,
                        fontWeight = FontWeight.Bold,
                        color = CyberEmerald
                    )
                }
                Text(
                    "STABLE PORT",
                    fontFamily = FontFamily.Monospace,
                    fontSize = 9.sp,
                    color = TextGray
                )
            }
            Spacer(modifier = Modifier.height(8.dp))
            
            Box(
                modifier = Modifier
                    .fillMaxWidth()
                    .height(120.dp)
                    .background(Color(0xFF070707), RoundedCornerShape(6.dp))
                    .border(0.5.dp, Color.DarkGray, RoundedCornerShape(6.dp))
                    .padding(8.dp)
            ) {
                LazyColumn(
                    modifier = Modifier.fillMaxSize(),
                    reverseLayout = false
                ) {
                    items(logs.take(30)) { log ->
                        Text(
                            text = log,
                            color = if (log.contains("🚨") || log.contains("❌") || log.contains("警告")) WarningCrimson else CyberEmerald,
                            fontSize = 10.sp,
                            fontFamily = FontFamily.Monospace,
                            modifier = Modifier.padding(bottom = 2.dp)
                        )
                    }
                }
            }
        }
    }
}

// --- History Records Screen ---
@Composable
fun RecordsTabContent(viewModel: HrvViewModel) {
    val records by viewModel.savedRecords.collectAsStateWithLifecycle()
    val context = LocalContext.current

    if (records.isEmpty()) {
        Box(
            modifier = Modifier
                .fillMaxSize()
                .padding(24.dp),
            contentAlignment = Alignment.Center
        ) {
            Column(
                horizontalAlignment = Alignment.CenterHorizontally,
                verticalArrangement = Arrangement.Center
            ) {
                Icon(
                    imageVector = Icons.AutoMirrored.Filled.List,
                    contentDescription = null,
                    tint = TextGray,
                    modifier = Modifier.size(64.dp)
                )
                Spacer(modifier = Modifier.height(16.dp))
                Text(
                    text = "暂无历史生理监测记录",
                    fontSize = 16.sp,
                    fontWeight = FontWeight.Bold,
                    color = TextWhite
                )
                Spacer(modifier = Modifier.height(8.dp))
                Text(
                    text = "请先连接符合标准规范的蓝牙心率带电极胸带，湿润电极并湿透电极触点后，在主页点击 [开始监测记录] 归档首个医用级 HRV 报告。",
                    fontSize = 12.sp,
                    color = TextGray,
                    textAlign = TextAlign.Center,
                    lineHeight = 18.sp
                )
            }
        }
    } else {
        LazyColumn(
            modifier = Modifier.fillMaxSize(),
            contentPadding = PaddingValues(16.dp),
            verticalArrangement = Arrangement.spacedBy(12.dp)
        ) {
            items(records) { record ->
                HistoryRecordCard(
                    record = record,
                    onShareClick = { viewModel.exportAndShareRecord(context, record) },
                    onDeleteClick = { viewModel.deleteRecord(record) }
                )
            }
        }
    }
}

// --- History Record Card with Expansion and Sharing ---
@Composable
fun HistoryRecordCard(
    record: HrvRecord,
    onShareClick: () -> Unit,
    onDeleteClick: () -> Unit
) {
    var expanded by remember { mutableStateOf(false) }

    val formattedDate = SimpleDateFormat("yyyy-MM-dd HH:mm", Locale.getDefault()).format(Date(record.startTime))
    val durationSecs = (record.endTime - record.startTime) / 1000
    val durationText = "${durationSecs / 60}分${durationSecs % 60}秒"

    val isAbnormal = record.diagnostic.contains("🚨")
    val isModerate = record.diagnostic.contains("⏳") || record.diagnostic.contains("⚠️")
    val statusColor = when {
        isAbnormal -> WarningCrimson
        isModerate -> StressAmber
        else -> CyberEmerald
    }

    Card(
        modifier = Modifier
            .fillMaxWidth()
            .clickable { expanded = !expanded },
        colors = CardDefaults.cardColors(containerColor = CarbonSlateDark),
        border = BorderStroke(1.dp, CarbonBorder),
        shape = RoundedCornerShape(12.dp)
    ) {
        Column(
            modifier = Modifier
                .fillMaxWidth()
                .padding(14.dp),
            verticalArrangement = Arrangement.spacedBy(8.dp)
        ) {
            // Header: Date & Duration
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
            ) {
                Text(
                    text = formattedDate,
                    fontSize = 14.sp,
                    fontWeight = FontWeight.Bold,
                    color = TextWhite
                )
                Text(
                    text = "时值: $durationText",
                    fontSize = 12.sp,
                    color = TextGray,
                    fontWeight = FontWeight.Medium
                )
            }

            // Summary grid line
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween
            ) {
                Column {
                    Text("平均心率", fontSize = 10.sp, color = TextGray)
                    Text(
                        "${String.format("%.1f", record.avgHr)} bpm",
                        fontSize = 14.sp,
                        fontWeight = FontWeight.Bold,
                        color = TextWhite
                    )
                }
                Column {
                    Text("SDNN (张力)", fontSize = 10.sp, color = TextGray)
                    Text(
                        "${String.format("%.1f", record.sdnn)} ms",
                        fontSize = 14.sp,
                        fontWeight = FontWeight.Bold,
                        color = CyberEmerald
                    )
                }
                Column {
                    Text("RMSSD (疲劳)", fontSize = 10.sp, color = TextGray)
                    Text(
                        "${String.format("%.1f", record.rmssd)} ms",
                        fontSize = 14.sp,
                        fontWeight = FontWeight.Bold,
                        color = AutonomicVioletLight
                    )
                }
                Column {
                    Text("压力比 (LF/HF)", fontSize = 10.sp, color = TextGray)
                    Text(
                        String.format("%.2f", record.lfHf),
                        fontSize = 14.sp,
                        fontWeight = FontWeight.Bold,
                        color = if (record.lfHf > 2.0) WarningCrimson else CyberEmerald
                    )
                }
            }

            // Diagnostic status block
            Box(
                modifier = Modifier
                    .fillMaxWidth()
                    .background(statusColor.copy(alpha = 0.08f), RoundedCornerShape(6.dp))
                    .border(0.5.dp, statusColor.copy(alpha = 0.3f), RoundedCornerShape(6.dp))
                    .padding(8.dp)
            ) {
                Row(verticalAlignment = Alignment.CenterVertically) {
                    Icon(
                        imageVector = if (isAbnormal) Icons.Default.Warning else Icons.Default.Info,
                        contentDescription = null,
                        tint = statusColor,
                        modifier = Modifier.size(14.dp)
                    )
                    Spacer(modifier = Modifier.width(6.dp))
                    Text(
                        text = "会话诊断: ${record.diagnostic}",
                        fontSize = 11.sp,
                        color = statusColor,
                        fontWeight = FontWeight.Bold
                    )
                }
            }

            // Expanded view of detailed txt logs
            AnimatedVisibility(visible = expanded) {
                Column(
                    modifier = Modifier
                        .fillMaxWidth()
                        .padding(top = 8.dp),
                    verticalArrangement = Arrangement.spacedBy(10.dp)
                ) {
                    Box(
                        modifier = Modifier
                            .fillMaxWidth()
                            .height(180.dp)
                            .background(Color.Black, RoundedCornerShape(8.dp))
                            .border(1.dp, CarbonBorder, RoundedCornerShape(8.dp))
                            .padding(8.dp)
                    ) {
                        val terminalScroll = rememberScrollState()
                        Text(
                            text = record.logContent,
                            color = CyberEmerald,
                            fontSize = 9.sp,
                            fontFamily = FontFamily.Monospace,
                            modifier = Modifier
                                .fillMaxSize()
                                .verticalScroll(terminalScroll)
                        )
                    }

                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.End,
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        IconButton(
                            onClick = onDeleteClick,
                            modifier = Modifier
                                .size(36.dp)
                                .background(WarningCrimson.copy(alpha = 0.1f), CircleShape)
                                .border(1.dp, WarningCrimson.copy(alpha = 0.2f), CircleShape)
                        ) {
                            Icon(Icons.Default.Delete, contentDescription = "删除记录", tint = WarningCrimson, modifier = Modifier.size(16.dp))
                        }
                        Spacer(modifier = Modifier.width(12.dp))
                        
                        Button(
                            onClick = onShareClick,
                            colors = ButtonDefaults.buttonColors(containerColor = CyberEmerald),
                            shape = RoundedCornerShape(6.dp),
                            modifier = Modifier.height(36.dp)
                        ) {
                            Icon(Icons.Default.Share, contentDescription = null, tint = CarbonBlack, modifier = Modifier.size(16.dp))
                            Spacer(modifier = Modifier.width(6.dp))
                            Text("导出并分享数据 (.txt)", fontSize = 11.sp, fontWeight = FontWeight.Bold, color = CarbonBlack)
                        }
                    }
                }
            }
        }
    }
}

// --- Device Scan Dialog/Drawer Overlay ---
@Composable
fun ScanningDialog(
    devices: List<BleDeviceItem>,
    onDeviceSelected: (BleDeviceItem) -> Unit,
    onDismiss: () -> Unit,
    isScanning: Boolean,
    onRescan: () -> Unit
) {
    Surface(
        color = Color.Black.copy(alpha = 0.85f),
        modifier = Modifier
            .fillMaxSize()
            .clickable { /* Block clicks to underlay */ }
    ) {
        Box(
            contentAlignment = Alignment.Center,
            modifier = Modifier.fillMaxSize()
        ) {
            Card(
                modifier = Modifier
                    .fillMaxWidth(0.9f)
                    .fillMaxHeight(0.7f),
                colors = CardDefaults.cardColors(containerColor = CarbonSlateDark),
                border = BorderStroke(1.dp, CarbonBorder),
                shape = RoundedCornerShape(16.dp)
            ) {
                Column(
                    modifier = Modifier
                        .fillMaxSize()
                        .padding(20.dp),
                    verticalArrangement = Arrangement.spacedBy(12.dp)
                ) {
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.SpaceBetween,
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Text(
                            "锁定蓝牙 BLE 心率胸带",
                            fontSize = 16.sp,
                            fontWeight = FontWeight.Bold,
                            color = TextWhite
                        )
                        IconButton(onClick = onDismiss) {
                            Icon(Icons.Default.Stop, contentDescription = "取消扫描", tint = WarningCrimson)
                        }
                    }

                    // Scanning state indicator
                    Row(
                        verticalAlignment = Alignment.CenterVertically,
                        modifier = Modifier
                            .fillMaxWidth()
                            .background(CarbonSlateCard, RoundedCornerShape(8.dp))
                            .padding(12.dp)
                    ) {
                        if (isScanning) {
                            CircularProgressIndicator(
                                modifier = Modifier.size(20.dp),
                                color = CyberEmerald,
                                strokeWidth = 2.dp
                            )
                            Spacer(modifier = Modifier.width(12.dp))
                            Text(
                                "正在广播频段检索心率胸带电极...",
                                fontSize = 11.sp,
                                color = CyberEmerald,
                                fontWeight = FontWeight.Medium
                            )
                        } else {
                            Icon(
                                Icons.Default.BluetoothConnected,
                                contentDescription = null,
                                tint = TextGray,
                                modifier = Modifier.size(20.dp)
                            )
                            Spacer(modifier = Modifier.width(12.dp))
                            Text(
                                "检索完毕。",
                                fontSize = 11.sp,
                                color = TextGray
                            )
                        }
                    }

                    // Devices list
                    LazyColumn(
                        modifier = Modifier
                            .weight(1f)
                            .fillMaxWidth(),
                        verticalArrangement = Arrangement.spacedBy(8.dp)
                    ) {
                        if (devices.isEmpty()) {
                            item {
                                Box(
                                    modifier = Modifier
                                        .fillMaxWidth()
                                        .padding(24.dp),
                                    contentAlignment = Alignment.Center
                                ) {
                                    Text(
                                        "未找到任何活跃的心率带信号。\n请确认胸带电极已被充足温水打湿以连通皮肤通路，并处于胸骨位置佩戴正确。",
                                        fontSize = 11.sp,
                                        color = TextGray,
                                        textAlign = TextAlign.Center,
                                        lineHeight = 16.sp
                                    )
                                }
                            }
                        } else {
                            items(devices) { item ->
                                Row(
                                    modifier = Modifier
                                        .fillMaxWidth()
                                        .background(CarbonSlateCard, RoundedCornerShape(8.dp))
                                        .border(0.5.dp, CarbonBorder, RoundedCornerShape(8.dp))
                                        .clickable { onDeviceSelected(item) }
                                        .padding(14.dp),
                                    horizontalArrangement = Arrangement.SpaceBetween,
                                    verticalAlignment = Alignment.CenterVertically
                                ) {
                                    Row(verticalAlignment = Alignment.CenterVertically) {
                                        Icon(
                                            Icons.Default.Bluetooth,
                                            contentDescription = null,
                                            tint = CyberEmerald
                                        )
                                        Spacer(modifier = Modifier.width(12.dp))
                                        Column {
                                            Text(
                                                item.name,
                                                fontSize = 14.sp,
                                                fontWeight = FontWeight.Bold,
                                                color = TextWhite
                                            )
                                            Text(
                                                item.address,
                                                fontSize = 11.sp,
                                                color = TextGray,
                                                fontFamily = FontFamily.Monospace
                                            )
                                        }
                                    }
                                    Text(
                                        "连接 👉",
                                        fontSize = 12.sp,
                                        fontWeight = FontWeight.Bold,
                                        color = CyberEmerald
                                    )
                                }
                            }
                        }
                    }

                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.spacedBy(10.dp)
                    ) {
                        OutlinedButton(
                            onClick = onDismiss,
                            modifier = Modifier.weight(1f),
                            shape = RoundedCornerShape(8.dp),
                            colors = ButtonDefaults.outlinedButtonColors(contentColor = TextGray)
                        ) {
                            Text("关闭窗口", fontSize = 13.sp)
                        }

                        if (!isScanning) {
                            Button(
                                onClick = onRescan,
                                modifier = Modifier.weight(1f),
                                shape = RoundedCornerShape(8.dp),
                                colors = ButtonDefaults.buttonColors(containerColor = CyberEmerald)
                            ) {
                                Icon(
                                    Icons.Default.Refresh,
                                    contentDescription = null,
                                    tint = CarbonBlack,
                                    modifier = Modifier.size(16.dp)
                                )
                                Spacer(modifier = Modifier.width(6.dp))
                                Text("重扫", fontSize = 13.sp, color = CarbonBlack)
                            }
                        }
                    }
                }
            }
        }
    }
}

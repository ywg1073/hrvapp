package com.example.ble

import android.Manifest
import android.annotation.SuppressLint
import android.bluetooth.BluetoothAdapter
import android.bluetooth.BluetoothDevice
import android.bluetooth.BluetoothGatt
import android.bluetooth.BluetoothGattCallback
import android.bluetooth.BluetoothGattCharacteristic
import android.bluetooth.BluetoothGattDescriptor
import android.bluetooth.BluetoothManager
import android.bluetooth.BluetoothProfile
import android.bluetooth.le.ScanCallback
import android.bluetooth.le.ScanFilter
import android.bluetooth.le.ScanResult
import android.bluetooth.le.ScanSettings
import android.content.Context
import android.content.pm.PackageManager
import android.os.Build
import android.os.Handler
import android.os.Looper
import android.os.ParcelUuid
import androidx.core.content.ContextCompat
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import java.util.UUID

enum class BleConnectionState {
    DISCONNECTED,
    SCANNING,
    CONNECTING,
    CONNECTED,
    DISCOVERING_SERVICES,
    SUBSCRIBED
}

data class BleDeviceItem(
    val name: String,
    val address: String,
    val device: BluetoothDevice
)

data class ParsedHrPacket(
    val heartRate: Int,
    val rrIntervals: List<Double>
)

class BleHeartRateManager(private val context: Context) {

    companion object {
        val UUID_HEART_RATE_SERVICE: UUID = UUID.fromString("0000180d-0000-1000-8000-00805f9b34fb")
        val UUID_HEART_RATE_MEASUREMENT: UUID = UUID.fromString("00002a37-0000-1000-8000-00805f9b34fb")
        val UUID_CLIENT_CHARACTERISTIC_CONFIG: UUID = UUID.fromString("00002902-0000-1000-8000-00805f9b34fb")
    }

    private val bluetoothManager: BluetoothManager? = 
        context.getSystemService(Context.BLUETOOTH_SERVICE) as? BluetoothManager
    private val bluetoothAdapter: BluetoothAdapter? = bluetoothManager?.adapter

    private var bluetoothGatt: BluetoothGatt? = null
    private var scanCallback: ScanCallback? = null
    private val handler = Handler(Looper.getMainLooper())
    private var isScanning = false
    private var isAutoReconnecting = false
    private var lastConnectedDevice: BluetoothDevice? = null

    // --- State Flows ---
    private val _connectionState = MutableStateFlow(BleConnectionState.DISCONNECTED)
    val connectionState: StateFlow<BleConnectionState> = _connectionState.asStateFlow()

    private val _scannedDevices = MutableStateFlow<List<BleDeviceItem>>(emptyList())
    val scannedDevices: StateFlow<List<BleDeviceItem>> = _scannedDevices.asStateFlow()

    private val _logFlow = MutableStateFlow<List<String>>(listOf("📊 BLE 系统就绪，等待扫描..."))
    val logFlow: StateFlow<List<String>> = _logFlow.asStateFlow()

    private val _hrDataFlow = MutableStateFlow<ParsedHrPacket?>(null)
    val hrDataFlow: StateFlow<ParsedHrPacket?> = _hrDataFlow.asStateFlow()

    fun addLog(message: String) {
        val currentLogs = _logFlow.value.toMutableList()
        currentLogs.add(0, "[${getFormattedTime()}] $message") // Newest logs first
        if (currentLogs.size > 150) {
            currentLogs.removeAt(currentLogs.size - 1)
        }
        _logFlow.value = currentLogs
    }

    private fun getFormattedTime(): String {
        val calendar = java.util.Calendar.getInstance()
        return String.format(
            "%02d:%02d:%02d",
            calendar.get(java.util.Calendar.HOUR_OF_DAY),
            calendar.get(java.util.Calendar.MINUTE),
            calendar.get(java.util.Calendar.SECOND)
        )
    }

    // --- Permissions helper ---
    fun hasRequiredPermissions(): Boolean {
        val permissions = mutableListOf<String>()
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.S) {
            permissions.add(Manifest.permission.BLUETOOTH_SCAN)
            permissions.add(Manifest.permission.BLUETOOTH_CONNECT)
        } else {
            permissions.add(Manifest.permission.ACCESS_FINE_LOCATION)
            permissions.add(Manifest.permission.ACCESS_COARSE_LOCATION)
        }
        
        return permissions.all {
            ContextCompat.checkSelfPermission(context, it) == PackageManager.PERMISSION_GRANTED
        }
    }

    fun getRequiredPermissionsList(): List<String> {
        val list = mutableListOf<String>()
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.S) {
            list.add(Manifest.permission.BLUETOOTH_SCAN)
            list.add(Manifest.permission.BLUETOOTH_CONNECT)
        } else {
            list.add(Manifest.permission.ACCESS_FINE_LOCATION)
            list.add(Manifest.permission.ACCESS_COARSE_LOCATION)
        }
        return list
    }

    // --- BLE Scan Engine ---
    @SuppressLint("MissingPermission")
    fun startScan(timeoutMs: Long = 10000L) {
        if (!hasRequiredPermissions()) {
            addLog("⚠️ 扫描失败: 缺少蓝牙/定位权限")
            return
        }
        if (bluetoothAdapter == null || !bluetoothAdapter.isEnabled) {
            addLog("❌ 扫描失败: 请在手机设置中开启蓝牙")
            return
        }
        if (isScanning) return

        _scannedDevices.value = emptyList()
        _connectionState.value = BleConnectionState.SCANNING
        addLog("🔍 正在全网异步检索符合标准规范的蓝牙心率硬件...")

        val scanner = bluetoothAdapter.bluetoothLeScanner
        if (scanner == null) {
            addLog("❌ 无法获取 BLE 扫描器，重置状态")
            _connectionState.value = BleConnectionState.DISCONNECTED
            return
        }

        val filters = listOf(
            ScanFilter.Builder()
                .setServiceUuid(ParcelUuid(UUID_HEART_RATE_SERVICE))
                .build()
        )
        val settings = ScanSettings.Builder()
            .setScanMode(ScanSettings.SCAN_MODE_LOW_LATENCY)
            .build()

        scanCallback = object : ScanCallback() {
            override fun onScanResult(callbackType: Int, result: ScanResult) {
                val device = result.device
                val deviceName = result.scanRecord?.deviceName ?: device.name ?: "Unknown Device"
                val deviceAddress = device.address

                val currentList = _scannedDevices.value
                if (currentList.none { it.address == deviceAddress }) {
                    val newList = currentList + BleDeviceItem(deviceName, deviceAddress, device)
                    _scannedDevices.value = newList
                    addLog("🎯 锁定目标广播: $deviceName [$deviceAddress]")
                }
            }

            override fun onScanFailed(errorCode: Int) {
                addLog("❌ 扫描底层发生错误，代码: $errorCode")
                isScanning = false
                _connectionState.value = BleConnectionState.DISCONNECTED
            }
        }

        isScanning = true
        scanner.startScan(filters, settings, scanCallback)

        // Stop scanning after timeout
        handler.postDelayed({
            stopScan()
        }, timeoutMs)
    }

    @SuppressLint("MissingPermission")
    fun stopScan() {
        if (!isScanning) return
        isScanning = false
        val scanner = bluetoothAdapter?.bluetoothLeScanner
        val callback = scanCallback
        if (scanner != null && callback != null) {
            scanner.stopScan(callback)
        }
        scanCallback = null
        if (_connectionState.value == BleConnectionState.SCANNING) {
            _connectionState.value = BleConnectionState.DISCONNECTED
            addLog("⏹️ 扫描已完成或手动停止。")
        }
    }

    // --- Connection logic ---
    @SuppressLint("MissingPermission")
    fun connectToDevice(deviceAddress: String) {
        val device = bluetoothAdapter?.getRemoteDevice(deviceAddress) ?: return
        connectToDevice(device)
    }

    @SuppressLint("MissingPermission")
    fun connectToDevice(device: BluetoothDevice) {
        stopScan()
        disconnect()

        lastConnectedDevice = device
        _connectionState.value = BleConnectionState.CONNECTING
        addLog("🔗 正在发起连接: ${device.name ?: "Unknown"} [${device.address}]")

        bluetoothGatt = device.connectGatt(context, false, gattCallback)
    }

    @SuppressLint("MissingPermission")
    fun disconnect() {
        isAutoReconnecting = false
        bluetoothGatt?.let { gatt ->
            addLog("🔌 正在主动断开连接...")
            gatt.disconnect()
            gatt.close()
        }
        bluetoothGatt = null
        _connectionState.value = BleConnectionState.DISCONNECTED
    }

    // --- BLE GATT Callback ---
    private val gattCallback = object : BluetoothGattCallback() {
        
        @SuppressLint("MissingPermission")
        override fun onConnectionStateChange(gatt: BluetoothGatt, status: Int, newState: Int) {
            val deviceName = gatt.device.name ?: "Unknown"
            val deviceAddress = gatt.device.address

            if (status == BluetoothGatt.GATT_SUCCESS) {
                when (newState) {
                    BluetoothProfile.STATE_CONNECTED -> {
                        _connectionState.value = BleConnectionState.CONNECTED
                        addLog("✅ 物理连接确立 [$deviceAddress]。正在探索服务列表...")
                        handler.post {
                            gatt.discoverServices()
                        }
                    }
                    BluetoothProfile.STATE_DISCONNECTED -> {
                        _connectionState.value = BleConnectionState.DISCONNECTED
                        addLog("⚠️ 物理链路断开 [$deviceAddress]！")
                        gatt.close()
                        bluetoothGatt = null
                        triggerAutoReconnect()
                    }
                }
            } else {
                _connectionState.value = BleConnectionState.DISCONNECTED
                addLog("🔌 链路底层握手异常，错误状态码: $status")
                gatt.close()
                bluetoothGatt = null
                triggerAutoReconnect()
            }
        }

        @SuppressLint("MissingPermission")
        override fun onServicesDiscovered(gatt: BluetoothGatt, status: Int) {
            if (status == BluetoothGatt.GATT_SUCCESS) {
                _connectionState.value = BleConnectionState.DISCOVERING_SERVICES
                addLog("📖 服务目录探索完毕。正在订阅心率特征值通知...")

                val service = gatt.getService(UUID_HEART_RATE_SERVICE)
                val characteristic = service?.getCharacteristic(UUID_HEART_RATE_MEASUREMENT)

                if (characteristic != null) {
                    gatt.setCharacteristicNotification(characteristic, true)
                    
                    val descriptor = characteristic.getDescriptor(UUID_CLIENT_CHARACTERISTIC_CONFIG)
                    if (descriptor != null) {
                        descriptor.value = BluetoothGattDescriptor.ENABLE_NOTIFICATION_VALUE
                        val writeSuccess = gatt.writeDescriptor(descriptor)
                        if (writeSuccess) {
                            _connectionState.value = BleConnectionState.SUBSCRIBED
                            addLog("📡 心率特征订阅使能成功！实时数据同步中...")
                            isAutoReconnecting = false // Successfully established full pipeline
                        } else {
                            addLog("❌ 特征描述符写入失败，数据流未使能")
                            _connectionState.value = BleConnectionState.CONNECTED
                        }
                    } else {
                        addLog("❌ 未找到 CCCD 描述符，无法启用通知")
                    }
                } else {
                    addLog("❌ 未找到标准心率特征值 (0x2A37)")
                }
            } else {
                addLog("❌ 服务发现失败，状态码: $status")
                disconnect()
            }
        }

        @Deprecated("Deprecated in Java")
        override fun onCharacteristicChanged(gatt: BluetoothGatt, characteristic: BluetoothGattCharacteristic) {
            if (characteristic.uuid == UUID_HEART_RATE_MEASUREMENT) {
                val value = characteristic.value
                val parsed = parseHeartRateMeasurement(value)
                if (parsed != null) {
                    _hrDataFlow.value = parsed
                }
            }
        }

        // Standard callback for API 33+ (though the deprecated one works as fallback on older versions, having both ensures robustness)
        override fun onCharacteristicChanged(
            gatt: BluetoothGatt,
            characteristic: BluetoothGattCharacteristic,
            value: ByteArray
        ) {
            if (characteristic.uuid == UUID_HEART_RATE_MEASUREMENT) {
                val parsed = parseHeartRateMeasurement(value)
                if (parsed != null) {
                    _hrDataFlow.value = parsed
                }
            }
        }
    }

    // --- Parse 0x2A37 GATT Packet ---
    private fun parseHeartRateMeasurement(data: ByteArray): ParsedHrPacket? {
        if (data.isEmpty()) return null
        val flags = data[0].toInt()

        val isHeartRate16Bit = (flags and 0x01) != 0
        val isEnergyPresent = (flags and 0x08) != 0
        val isRrIntervalPresent = (flags and 0x10) != 0

        var offset = 1

        val heartRate = if (isHeartRate16Bit) {
            if (offset + 2 > data.size) return null
            val hr = ((data[offset + 1].toInt() and 0xFF) shl 8) or (data[offset].toInt() and 0xFF)
            offset += 2
            hr
        } else {
            if (offset + 1 > data.size) return null
            val hr = data[offset].toInt() and 0xFF
            offset += 1
            hr
        }

        if (isEnergyPresent) {
            offset += 2
        }

        val rrIntervals = mutableListOf<Double>()
        if (isRrIntervalPresent) {
            while (offset + 2 <= data.size) {
                val rrRaw = ((data[offset + 1].toInt() and 0xFF) shl 8) or (data[offset].toInt() and 0xFF)
                offset += 2
                // Standard: unit is 1/1024 of a second, convert to ms
                val rrMs = (rrRaw.toDouble() / 1024.0) * 1000.0
                rrIntervals.add(rrMs)
            }
        }

        return ParsedHrPacket(heartRate, rrIntervals)
    }

    // --- Auto Reconnect Routine ---
    @SuppressLint("MissingPermission")
    private fun triggerAutoReconnect() {
        val device = lastConnectedDevice
        if (device == null || isAutoReconnecting) return
        isAutoReconnecting = true
        addLog("💤 5秒后将全自动启动重连轮询机制...")
        handler.postDelayed({
            if (isAutoReconnecting && lastConnectedDevice != null) {
                addLog("🔄 正在自动尝试重连: ${lastConnectedDevice?.name ?: "Device"} [${lastConnectedDevice?.address}]")
                bluetoothGatt = lastConnectedDevice?.connectGatt(context, false, gattCallback)
            }
        }, 5000L)
    }
}

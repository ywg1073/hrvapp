package com.example.ui.theme

import androidx.compose.ui.graphics.Color

// Primary Accent - Cyber Heart Emerald
val CyberEmerald = Color(0xFF10B981)
val CyberEmeraldDark = Color(0xFF047857)

// Secondary Accent - Autonomic Violet
val AutonomicViolet = Color(0xFF8B5CF6)
val AutonomicVioletLight = Color(0xFFC4B5FD)

// Tertiary Accent - Stress Amber
val StressAmber = Color(0xFFF59E0B)

// Core Dark Background & Surfaces (Carbon Slate)
val CarbonBlack = Color(0xFF0B0E14)
val CarbonSlateDark = Color(0xFF111622)
val CarbonSlateCard = Color(0xFF1C2333)
val CarbonBorder = Color(0xFF2E3B53)

// Alert Red - Arrhythmia Crimson
val WarningCrimson = Color(0xFFEF4444)

// Text Colors
val TextWhite = Color(0xFFF9FAFB)
val TextGray = Color(0xFF9CA3AF)
val TextDark = Color(0xFF111827)

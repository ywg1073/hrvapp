package com.example.ui.theme

import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.darkColorScheme
import androidx.compose.runtime.Composable

private val CarbonDarkColorScheme = darkColorScheme(
    primary = CyberEmerald,
    secondary = AutonomicViolet,
    tertiary = StressAmber,
    background = CarbonBlack,
    surface = CarbonSlateDark,
    surfaceVariant = CarbonSlateCard,
    onPrimary = CarbonBlack,
    onSecondary = TextWhite,
    onTertiary = CarbonBlack,
    onBackground = TextWhite,
    onSurface = TextWhite,
    onError = TextWhite,
    error = WarningCrimson
)

@Composable
fun MyApplicationTheme(
    darkTheme: Boolean = true, // Force dark theme for professional dashboard aesthetic
    dynamicColor: Boolean = false, // Disable dynamic colors to keep precise high-fidelity color brand cohesive
    content: @Composable () -> Unit
) {
    val colorScheme = CarbonDarkColorScheme

    MaterialTheme(
        colorScheme = colorScheme,
        typography = Typography,
        content = content
    )
}

